
public class Ex00_Hello {
	
	public static void main(String[] args) {
		System.out.println("** Console Output Test **");
		System.out.println("~~ Hello Java  ummsam  !!! ~~");
		System.out.println("~~ Update Test !!! ~~");
	} //main
	
} //class
